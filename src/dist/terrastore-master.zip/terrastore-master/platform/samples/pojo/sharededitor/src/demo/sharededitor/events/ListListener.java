/*
 *
 * All content copyright Terracotta, Inc., unless otherwise indicated. All rights reserved.
 *
 */
package demo.sharededitor.events;

public interface ListListener {
	void changed(Object source, Object obj);
}
